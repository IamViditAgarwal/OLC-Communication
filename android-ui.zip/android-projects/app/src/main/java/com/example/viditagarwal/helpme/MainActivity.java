package com.example.viditagarwal.helpme;

import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    String toPhoneNumberET = "+918802782944";
    String myCode = "G5VV+6C New Delhi, Delhi";
    EditText smsMessageET;


    LinearLayout form_wrapper;
    TextView  loc_code, location_form, location_form_info, location_code, messge, helpline_grp, helpline ;
    EditText  msg ;
    Button sendSMSBtn;
    Spinner org ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* Map all the UI elements in the java code */
        sendSMSBtn = (Button) findViewById(R.id.sendSMSBtn);

        // Linear Layout
        form_wrapper = (LinearLayout)findViewById(R.id.form_wrapper);

        // Form Elements
        location_form = (TextView)findViewById(R.id.location_form);
        location_form_info = (TextView)findViewById(R.id.location_form_info) ;
        location_code = (TextView)findViewById(R.id.location_code);
        messge = (TextView)findViewById(R.id.messge);
     //   helpline_grp = (TextView)findViewById(R.id.helpline_grp);
        helpline = (TextView)findViewById(R.id.helpline);

        // Input Elements
        loc_code = (TextView)findViewById(R.id.loc_code);
        msg = (EditText)findViewById(R.id.msg);

        // Select Element
        org = (Spinner)findViewById(R.id.helpline_select) ;

        // Set the colors of textviews;
        location_form.setTextColor(Color.parseColor("#009874"));
        location_code.setTextColor(Color.parseColor("#009874"));
        messge.setTextColor(Color.parseColor("#009874"));
        helpline.setTextColor(Color.parseColor("#009874"));

        sendSMSBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                String org_name  = String.valueOf(org.getSelectedItem());
                sendSMS(org_name);
            }
        });
    }

    protected  void sendSMS(String org_name){
        String toPhoneNumber = toPhoneNumberET;
        // get the user location codde
        String loc_code = myCode ;//loc_code.getText().toString();
        String messg = msg.getText().toString();

        String final_mssg = "{ \"code\" : \""+loc_code+"\" , \"mssg\" : \""+messg+ "\", \"org\" : \"" +org_name+"\"}";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(toPhoneNumber, null, final_mssg, null, null);
            Toast.makeText(getApplicationContext(), "SMS sent.",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),
                    "Sending SMS failed.",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}
